package com.example.canteenapps;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class activity_order extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        // Ensure you have a view with id "main" in your activity_order.xml layout
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            WindowInsetsCompat insetsCompat = insets;
            int left = insetsCompat.getInsets(WindowInsetsCompat.Type.systemBars()).left;
            int top = insetsCompat.getInsets(WindowInsetsCompat.Type.systemBars()).top;
            int right = insetsCompat.getInsets(WindowInsetsCompat.Type.systemBars()).right;
            int bottom = insetsCompat.getInsets(WindowInsetsCompat.Type.systemBars()).bottom;

            v.setPadding(left, top, right, bottom);
            return insetsCompat;
        });
    }
}
